<nav class="navbar">
  <div class="logo">LOGO</div>

  <ul>
    <li><a href="#about">ABOUT</a></li>
    <li><a href="#services">SERVICES</a></li>
    <li><a href="#works">WORKS</a></li>
  </ul>
</nav>

<style>
  .navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: white;
    display: flex;
    justify-content: space-between;
    padding: 25px 80px;
    border-bottom: 1px solid #000;
  }

  .logo {
    font-weight: 800;
    letter-spacing: 2px;
  }

  ul {
    display: flex;
    gap: 50px;
    list-style: none;
  }

  a {
    text-decoration: none;
    color: black;
    font-size: 14px;
    letter-spacing: 1.5px;
  }

  a:hover {
    opacity: 0.5;
  }
</style>