<footer>
  <div class="container">
    <h3>CONTACT</h3>
    <p>hello@example.com</p>
  </div>
</footer>

<style>
  footer {
    border-top: 1px solid black;
    padding: 100px 0;
  }
</style>